# Query2PDF
Generate A PDF report with only a SQL query. It is also possible to customize the report.
# Downloading the plugin
You can download the plugin on the [demo site](https://apex.oracle.com/pls/apex/f?p=SMART4SOLUTIONS:240 "Demo site on apex.oracle.com")
# Using the plugin
1. Add a dynamic action to the page
2. Choose action "SMART4solutions PDF download"
3. Enter a SQL query into the source (Example: select * from emp)
4. Enter a filename
5. It is possible to customize the report, like color or font size
